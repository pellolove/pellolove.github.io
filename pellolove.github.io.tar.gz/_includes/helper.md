你可以加载这些包含部分到你的布局或者文章中以方便重用。
可以用这个标签  {% include file.ext %} 
来把文件 _includes/file.ext 包含进来。